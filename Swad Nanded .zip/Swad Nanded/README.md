# Swad Nanded - Local Restaurant Website

A fully functional restaurant website for "Swad Nanded" featuring online menu browsing and order placement.

## Features

- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Interactive Menu**: Browse menu items by categories (All, Main Course, Snacks, Beverages)
- **Shopping Cart**: Add items to cart, update quantities, remove items
- **Order Placement**: Complete order form with customer details
- **Order Tracking**: Order confirmation with unique order ID
- **Local Storage**: Orders are saved locally for demonstration

## Menu Categories

### Main Course
- Nanded Special Thali (₹180)
- Mutton Curry (₹250)
- Chicken Biryani (₹220)

### Snacks
- Vada Pav (₹25)
- Misal Pav (₹60)
- Pani Puri (₹40)

### Beverages
- Masala Chai (₹15)
- Fresh Lime Soda (₹30)
- Lassi (₹35)

## How to Use

1. Open `index.html` in your web browser
2. Browse the menu by clicking category buttons
3. Add items to cart using "Add to Cart" buttons
4. Click on "Cart" to view your order
5. Adjust quantities or remove items as needed
6. Click "Place Order" to proceed to checkout
7. Fill in your details and confirm the order

## File Structure

```
swad-nanded-restaurant/
├── index.html          # Main HTML file
├── css/
│   └── style.css      # Styling and responsive design
├── js/
│   └── script.js      # JavaScript functionality
├── images/            # Folder for restaurant images
└── README.md          # This file
```

## Technologies Used

- HTML5
- CSS3 (with Flexbox and Grid)
- Vanilla JavaScript
- Local Storage for order persistence

## Restaurant Information

- **Name**: Swad Nanded
- **Location**: Main Street, Nanded, Maharashtra
- **Phone**: +91 9876543210
- **Hours**: 11:00 AM - 10:00 PM

## Future Enhancements

- Payment gateway integration
- Real-time order tracking
- User accounts and order history
- Admin panel for menu management
- Online reviews and ratings